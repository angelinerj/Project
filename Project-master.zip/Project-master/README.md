# Project
This project is take look at the files from MobaXterm documents and extract the data for different atoms of different Molecules.
In this code I have taken the Water molecule and extracted the data for Oxygen and Hydrogen, giving 6 different values, 3 for each atom.
The extracted data contains information about the rank of the atom, the fitted and anchor values too.
